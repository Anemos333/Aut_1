# Autotune corpus diff test pack

Files:
- `run_autotune_corpus_tests.py`: setup/build/run wrapper.
- `CorpusAudioDiffRunner.cpp`: JUCE console runner.
- `AutotuneCorpusDiff.cmake`: CMake target added to `Tests/`.

Why this runner uses the engine directly:
- In the current repo, the plugin is built as VST3/AU.
- The exhaustive values requested include root note and built-in scale. In the current code those are processor state/atomics, not APVTS host parameters, so a generic VST host may not expose them for automation.
- The runner therefore uses `ModernPitchEngine` + `ScaleDefinitions` directly and mirrors the modern plugin path for Quality, Live and Experimental/UltraLive modes.

Quick start:

```bash
cd /path/to/Aut_1
python3 /path/to/test_pack/run_autotune_corpus_tests.py \
  --repo . \
  --corpus /path/to/Voices.zip \
  --results ./corpus-diff-results \
  --max-seconds 10 \
  --stop-on-first-fail
```

Full exhaustive run:

```bash
cd /path/to/Aut_1
python3 /path/to/test_pack/run_autotune_corpus_tests.py \
  --repo . \
  --corpus /path/to/Voices.zip \
  --results ./corpus-diff-results \
  --threshold 85
```

The full run is intentionally huge:
`modes * roots * scales * parameter_sets` wet renders per voice.
With the current code that is typically `3 * 19 * ScaleDefinitions::getScaleCount() * 2`.
Every voice gets:
- original vs every wet render
- every wet render vs every other wet render

Output:
- one `<voice>/<voice>_diffs.txt` file per voice
- `corpus_summary.txt`
- stdout prints PASS/FAIL after each voice
- process exit code is 0 only if the whole corpus passes

Metric:
`100 * min(1, rms(a-b) / (rms(a) + rms(b) + eps))`
The PASS threshold defaults to 85%.
