#!/usr/bin/env python3
"""
Install and run the exhaustive Microtonal Autotune corpus diff test.

This wrapper:
  1) copies Tests/CorpusAudioDiffRunner.cpp and Tests/AutotuneCorpusDiff.cmake
     into the repo,
  2) includes the CMake snippet from Tests/AutotuneTests.cmake if missing,
  3) optionally extracts a .zip corpus,
  4) configures/builds the AutotuneCorpusDiff target,
  5) runs it over every supported audio file.

Dependencies: Python 3.9+, CMake, a C++17 compiler.
The repo's existing CMake fetches JUCE.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import zipfile


PACK_DIR = Path(__file__).resolve().parent
RUNNER_CPP = PACK_DIR / "CorpusAudioDiffRunner.cpp"
RUNNER_CMAKE = PACK_DIR / "AutotuneCorpusDiff.cmake"


def run(cmd: list[str], cwd: Path | None = None) -> None:
    print("+", " ".join(str(x) for x in cmd))
    subprocess.run(cmd, cwd=str(cwd) if cwd else None, check=True)


def copy_runner(repo: Path) -> None:
    tests = repo / "Tests"
    if not tests.exists():
        raise SystemExit(f"Missing Tests directory in repo: {tests}")

    shutil.copy2(RUNNER_CPP, tests / "CorpusAudioDiffRunner.cpp")
    shutil.copy2(RUNNER_CMAKE, tests / "AutotuneCorpusDiff.cmake")

    autotune_tests = tests / "AutotuneTests.cmake"
    if not autotune_tests.exists():
        raise SystemExit(f"Missing {autotune_tests}")

    include_line = "include(${CMAKE_CURRENT_LIST_DIR}/AutotuneCorpusDiff.cmake)"
    text = autotune_tests.read_text(encoding="utf-8")
    if include_line not in text:
        if not text.endswith("\n"):
            text += "\n"
        text += "\n# Exhaustive external corpus diff runner\n" + include_line + "\n"
        autotune_tests.write_text(text, encoding="utf-8")


def extract_or_use_corpus(corpus: Path, work_dir: Path) -> Path:
    if corpus.is_dir():
        return corpus.resolve()

    if not corpus.exists():
        raise SystemExit(f"Corpus path does not exist: {corpus}")

    if corpus.suffix.lower() != ".zip":
        raise SystemExit(f"Corpus must be a directory or a .zip file: {corpus}")

    out = work_dir / "corpus_unzipped"
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    with zipfile.ZipFile(corpus) as zf:
        zf.extractall(out)
    return out.resolve()


def is_executable(path: Path) -> bool:
    if not path.is_file():
        return False
    if os.name == "nt":
        return path.suffix.lower() == ".exe"
    return bool(path.stat().st_mode & stat.S_IXUSR)


def find_runner(build_dir: Path) -> Path:
    names = ["AutotuneCorpusDiff.exe", "AutotuneCorpusDiff"]
    candidates: list[Path] = []
    for name in names:
        candidates.extend(build_dir.rglob(name))

    candidates = [p for p in candidates if is_executable(p)]
    if not candidates:
        raise SystemExit(f"Could not find AutotuneCorpusDiff executable under {build_dir}")

    # Prefer Release artefacts when present.
    candidates.sort(key=lambda p: ("Release" not in str(p), len(str(p))))
    return candidates[0]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=".", type=Path, help="Path to Aut_1 repository")
    ap.add_argument("--corpus", required=True, type=Path, help="Corpus directory or zip")
    ap.add_argument("--build-dir", default="build-corpus-diff", type=Path)
    ap.add_argument("--results", default="corpus-diff-results", type=Path)
    ap.add_argument("--build-type", default="Release")
    ap.add_argument("--threshold", default=85.0, type=float)
    ap.add_argument("--block-size", default=256, type=int)
    ap.add_argument("--max-seconds", default=0.0, type=float,
                    help="Use e.g. 10 for a quick shakedown. 0 means full files.")
    ap.add_argument("--skip-build", action="store_true")
    ap.add_argument("--keep-wet", action="store_true",
                    help="Write all wet WAVs too. This can use huge disk space.")
    ap.add_argument("--stop-on-first-fail", action="store_true",
                    help="Useful for shakedown/debug; not exhaustive if it stops early.")
    args = ap.parse_args()

    repo = args.repo.resolve()
    build_dir = args.build_dir.resolve()
    results = args.results.resolve()
    work_dir = results / "_work"
    work_dir.mkdir(parents=True, exist_ok=True)

    copy_runner(repo)
    corpus_dir = extract_or_use_corpus(args.corpus.resolve(), work_dir)

    if not args.skip_build:
        cmake_config = [
            "cmake", "-S", str(repo), "-B", str(build_dir),
            f"-DCMAKE_BUILD_TYPE={args.build_type}",
            "-DBUILD_TESTING=ON",
            "-DAUTOTUNE_BUILD_TESTS=ON",
            "-DAUTOTUNE_BUILD_CORPUS_DIFF=ON",
        ]
        run(cmake_config)

        run([
            "cmake", "--build", str(build_dir),
            "--config", args.build_type,
            "--target", "AutotuneCorpusDiff",
            "--parallel",
        ])

    runner = find_runner(build_dir)

    cmd = [
        str(runner),
        "--input", str(corpus_dir),
        "--output", str(results),
        "--threshold", str(args.threshold),
        "--block-size", str(args.block_size),
        "--max-seconds", str(args.max_seconds),
    ]
    if args.keep_wet:
        cmd.append("--keep-wet")
    if args.stop_on_first_fail:
        cmd.append("--stop-on-first-fail")

    run(cmd)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
